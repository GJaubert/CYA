var searchData=
[
  ['inicio_19',['inicio',['../classgestor.html#a84a66b39e1a72ecef82321adbcfffc9e',1,'gestor']]]
];
