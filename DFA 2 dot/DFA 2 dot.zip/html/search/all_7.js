var searchData=
[
  ['label_20',['label',['../classgestor.html#a03a311478373eac470bc1758b93ed3b6',1,'gestor::label()'],['../classtransicion.html#aeaac95cf4c3e756869a2a30d73f62f3e',1,'transicion::label()']]],
  ['llegada_21',['llegada',['../classgestor.html#a3526d2dd4c0d8d2ab10899425d712d7f',1,'gestor']]]
];
