var searchData=
[
  ['read_28',['Read',['../classgestor.html#a673490742bca34b4535bbfe06752ff7d',1,'gestor']]]
];
