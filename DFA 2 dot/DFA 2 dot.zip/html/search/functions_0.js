var searchData=
[
  ['alfabeto_51',['alfabeto',['../classalfabeto.html#aa93506a5d1e3409c27bf01dea3d5676d',1,'alfabeto::alfabeto(std::string in, std::vector&lt; std::string &gt; vectorin)'],['../classalfabeto.html#a650c9d86e46f733595cbf8f04e0d6f5c',1,'alfabeto::alfabeto()']]]
];
