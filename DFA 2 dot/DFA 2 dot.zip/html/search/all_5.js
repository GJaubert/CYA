var searchData=
[
  ['gestor_17',['gestor',['../classgestor.html',1,'gestor'],['../classgestor.html#acc39fbd73b4b33e2704b5534459b621b',1,'gestor::gestor()']]],
  ['gestor_2eh_18',['gestor.h',['../gestor_8h.html',1,'']]]
];
