var searchData=
[
  ['numeroaceptacion_76',['numeroaceptacion',['../classestado.html#af8dff690e004654e7ded165b716abd72',1,'estado::numeroaceptacion()'],['../classgestor.html#abfb4ab14e7b68a330f72dfd740dbdb86',1,'gestor::numeroaceptacion()']]],
  ['numerodesimbolos_77',['numerodesimbolos',['../classalfabeto.html#adfd612ae8eee325a95fae61514745ae6',1,'alfabeto']]],
  ['numerosimbolos_78',['numerosimbolos',['../classgestor.html#ac423dc12bbf5db1a8f635b14c82db99a',1,'gestor']]],
  ['numerotransiciones_79',['numerotransiciones',['../classgestor.html#a4090663b285fdf42c61343186bdc0386',1,'gestor']]]
];
