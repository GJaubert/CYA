var indexSectionsWithContent =
{
  0: "acdefgilmnorstw",
  1: "adegt",
  2: "degt",
  3: "acdegmrtw",
  4: "acdefilnost"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables"
};

