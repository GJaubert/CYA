var searchData=
[
  ['transicion_45',['transicion',['../classtransicion.html',1,'']]]
];
