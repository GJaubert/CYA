var searchData=
[
  ['cantidadtransiciones_67',['cantidadtransiciones',['../classtransicion.html#a6f38d64dff36f258e9ab50cb9c3916e8',1,'transicion']]]
];
