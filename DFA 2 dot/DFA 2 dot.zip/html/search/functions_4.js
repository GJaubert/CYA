var searchData=
[
  ['gestor_57',['gestor',['../classgestor.html#acc39fbd73b4b33e2704b5534459b621b',1,'gestor']]]
];
