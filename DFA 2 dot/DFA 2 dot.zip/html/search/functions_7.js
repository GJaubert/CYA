var searchData=
[
  ['transicion_60',['transicion',['../classtransicion.html#a2e6c2d3f48dfa1e44bd6f3c559a5bc88',1,'transicion::transicion(std::string str1, std::string str2, std::string str3)'],['../classtransicion.html#a61f1df4abe205c846d7612a2703831b1',1,'transicion::transicion()']]]
];
