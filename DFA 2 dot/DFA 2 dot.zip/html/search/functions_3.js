var searchData=
[
  ['estado_56',['estado',['../classestado.html#a0c771206f97b8c3e25d29e2b86cacc85',1,'estado::estado(std::string strin, std::vector&lt; std::string &gt; vectorin)'],['../classestado.html#ad134e600cd34cb02e9735c597be1a5d5',1,'estado::estado()']]]
];
