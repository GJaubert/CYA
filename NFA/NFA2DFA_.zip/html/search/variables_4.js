var searchData=
[
  ['label_48',['label',['../classestado.html#abd7b982e1a3425b1ab0ed516a80059bc',1,'estado::label()'],['../classtransicion.html#aeaac95cf4c3e756869a2a30d73f62f3e',1,'transicion::label()']]]
];
