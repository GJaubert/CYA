var searchData=
[
  ['alfabeto_34',['alfabeto',['../classalfabeto.html#a650c9d86e46f733595cbf8f04e0d6f5c',1,'alfabeto::alfabeto()'],['../classalfabeto.html#a53b8cf1501b6f51bab8bef1be67823f3',1,'alfabeto::alfabeto(std::string str)']]]
];
