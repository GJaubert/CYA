var searchData=
[
  ['naceptacion_14',['naceptacion',['../classNFA.html#abe678bc5559113a2b9cb7bec03a9f352',1,'NFA']]],
  ['nestados_15',['nestados',['../classNFA.html#a969e5f44a97a0ab9b7802794ae56469c',1,'NFA']]],
  ['nfa_16',['NFA',['../classNFA.html',1,'NFA'],['../classNFA.html#a6a4e79c90998ebb75e7b6ce280b14bed',1,'NFA::NFA()']]],
  ['nsimbolos_17',['nsimbolos',['../classNFA.html#a250b9a6994150779351ad524f112a6b6',1,'NFA']]],
  ['ntransiciones_18',['ntransiciones',['../classNFA.html#a60b5d327413dc2a2db17a00f2e4db470',1,'NFA']]]
];
