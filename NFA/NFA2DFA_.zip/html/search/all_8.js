var searchData=
[
  ['salida_20',['salida',['../classtransicion.html#acdc0afc362733aa42f3801394c96952b',1,'transicion']]],
  ['simbolo_21',['simbolo',['../classalfabeto.html#ab3cf354fce76819a6ed6a1ce0cee18af',1,'alfabeto']]],
  ['simbolos_22',['simbolos',['../classNFA.html#a85526b62f751b0b3808606f7b8f8cd0e',1,'NFA']]]
];
